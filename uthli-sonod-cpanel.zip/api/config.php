<?php
/*
 * ডাটাবেস সেটিংস
 * cPanel → MySQL Databases থেকে যে ডাটাবেস, ইউজার ও পাসওয়ার্ড বানাবেন সেগুলো এখানে লিখুন।
 * cPanel-এ নামের আগে আপনার cPanel ইউজারনেম যুক্ত থাকে, যেমন: abcuser_sonod
 */
return [
    'db_host' => 'localhost',
    'db_name' => 'CPANELUSER_sonod',      // ← ডাটাবেসের পুরো নাম
    'db_user' => 'CPANELUSER_sonoduser',  // ← ডাটাবেস ইউজারের পুরো নাম
    'db_pass' => 'এখানে-ডাটাবেস-পাসওয়ার্ড', // ← ডাটাবেস ইউজারের পাসওয়ার্ড

    // লগইন কতক্ষণ থাকবে (ঘণ্টা)
    'admin_session_hours'   => 12,
    'citizen_session_hours' => 72,
];
