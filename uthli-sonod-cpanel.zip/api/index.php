<?php
/*
 * ডিজিটাল সনদ সেবা — সার্ভার API (PHP + MySQL)
 * সব /api/... রিকোয়েস্ট এই ফাইলে আসে (.htaccess এর মাধ্যমে)।
 */
declare(strict_types=1);
define('UTH_APP', 1);
require __DIR__ . '/lib.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

/* ---------------- উত্তর পাঠানোর সহায়ক ---------------- */
function out($data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function fail(string $msg, int $code = 400): void { out(['error' => $msg], $code); }

function body(): array {
    static $b = null;
    if ($b === null) {
        $j = json_decode((string)file_get_contents('php://input'), true);
        $b = is_array($j) ? $j : [];
    }
    return $b;
}
function s($v): string { return is_scalar($v) ? trim((string)$v) : ''; }

/* ---------------- সেটিংস ---------------- */
function get_cfg(): array {
    $r = db()->query("SELECT v FROM settings WHERE k='cfg'")->fetch();
    $c = $r ? json_decode($r['v'], true) : null;
    return is_array($c) ? $c : default_config();
}
function save_cfg(array $c): void {
    $st = db()->prepare("REPLACE INTO settings (k, v) VALUES ('cfg', ?)");
    $st->execute([json_encode($c, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
}

/* ---------------- লগইন সেশন ---------------- */
function bearer(): string {
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if (!$h && function_exists('getallheaders')) {
        foreach (getallheaders() as $k => $v) if (strtolower($k) === 'authorization') $h = $v;
    }
    return preg_match('/^Bearer\s+([a-f0-9]{64})$/i', trim($h), $m) ? strtolower($m[1]) : '';
}
function new_token(string $kind, int $uid): string {
    $t = bin2hex(random_bytes(32));
    $hrs = (int)(cfg_file()[$kind === 'admin' ? 'admin_session_hours' : 'citizen_session_hours'] ?? 12);
    db()->prepare("DELETE FROM sessions WHERE expires_at < ?")->execute([time()]);
    db()->prepare("INSERT INTO sessions (token_hash, kind, uid, expires_at) VALUES (?,?,?,?)")
        ->execute([hash('sha256', $t), $kind, $uid, time() + $hrs * 3600]);
    return $t;
}
function session_of(string $kind): ?int {
    $t = bearer();
    if (!$t) return null;
    $st = db()->prepare("SELECT uid FROM sessions WHERE token_hash=? AND kind=? AND expires_at>?");
    $st->execute([hash('sha256', $t), $kind, time()]);
    $r = $st->fetch();
    return $r ? (int)$r['uid'] : null;
}
function need_admin(): int {
    $u = session_of('admin');
    if ($u === null) fail('অনুগ্রহ করে আবার লগইন করুন।', 401);
    return $u;
}
function need_citizen(): int {
    $u = session_of('citizen');
    if ($u === null) fail('অনুগ্রহ করে আবার লগইন করুন।', 401);
    return $u;
}

/* বারবার ভুল পাসওয়ার্ড দিলে ১৫ মিনিট আটকে রাখা */
function client_ip(): string { return substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 64); }
function throttle_check(): void {
    $st = db()->prepare("SELECT COUNT(*) n FROM login_fail WHERE ip=? AND at>?");
    $st->execute([client_ip(), time() - 900]);
    if ((int)$st->fetch()['n'] >= 10) fail('অনেকবার ভুল চেষ্টা হয়েছে। ১৫ মিনিট পর আবার চেষ্টা করুন।', 429);
}
function throttle_fail(): void {
    db()->prepare("INSERT INTO login_fail (ip, at) VALUES (?,?)")->execute([client_ip(), time()]);
    db()->prepare("DELETE FROM login_fail WHERE at < ?")->execute([time() - 86400]);
}

/* ---------------- নাগরিক ---------------- */
const CIT_KEYS = ['doc_type','photo','name_bn','name_en','father_bn','father_en','mother_bn','mother_en','spouse_bn','spouse_en',
    'dob','gender','residency','ward','village_bn','marital','occupation','religion','nid','birth_reg','passport','mobile','house','holding'];

function norm_doc(string $v): string { return strtoupper(preg_replace('/[\s\-]+/u', '', en_digits(trim($v)))); }
function norm_mobile(string $v): string { return preg_replace('/[\s\-]+/', '', en_digits(trim($v))); }

function citizen_row(int $id): ?array {
    $st = db()->prepare("SELECT * FROM citizens WHERE id=?");
    $st->execute([$id]);
    $r = $st->fetch();
    return $r ?: null;
}
function citizen_public(array $r): array {
    $d = json_decode($r['data'], true);
    $d = is_array($d) ? $d : [];
    $d['id'] = (int)$r['id'];
    $d['has_account'] = $r['pass_hash'] ? 1 : 0;
    return $d;
}
function save_citizen_cols(int $id, array $d): void {
    db()->prepare("UPDATE citizens SET name_bn=?, mobile=?, nid=?, birth_reg=?, passport=?, dob=?, data=? WHERE id=?")->execute([
        mb_substr(s($d['name_bn'] ?? ''), 0, 190),
        mb_substr(norm_mobile(s($d['mobile'] ?? '')), 0, 20),
        mb_substr(norm_doc(s($d['nid'] ?? '')), 0, 40),
        mb_substr(norm_doc(s($d['birth_reg'] ?? '')), 0, 40),
        mb_substr(norm_doc(s($d['passport'] ?? '')), 0, 40),
        mb_substr(en_digits(s($d['dob'] ?? '')), 0, 20),
        json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        $id,
    ]);
}
function mobile_taken(string $mobile, int $exceptId): bool {
    $st = db()->prepare("SELECT id FROM citizens WHERE mobile=? AND pass_hash IS NOT NULL AND id<>? LIMIT 1");
    $st->execute([$mobile, $exceptId]);
    return (bool)$st->fetch();
}
function valid_image(string $d, int $maxBytes): bool {
    return $d === '' || (strlen($d) <= $maxBytes && preg_match('#^data:image/(jpeg|png|webp|gif);base64,[A-Za-z0-9+/=]+$#', $d));
}

/* ---------------- সনদের বিশেষ ঘর (ওয়ারিশ, পারিবারিক, ট্রেড লাইসেন্স ইত্যাদি) ---------------- */
const SPT = ['ওয়ারিশ সনদ'=>'heir','উত্তরাধিকার সনদ'=>'heir','পারিবারিক সনদ'=>'family','একই ব্যক্তির প্রত্যয়ন'=>'same','ট্রেড লাইসেন্স'=>'trade'];
function spf(): array {
    static $S = null;
    if ($S === null) $S = json_decode('{"heir":{"req":[["d_name","মৃত ব্যক্তির নাম"],["d_father","মৃত ব্যক্তির পিতা / স্বামীর নাম"],["d_date","মৃত্যুর তারিখ"],["ward","ওয়ার্ড নং"],["village","গ্রাম"]],"list":{"t":"ওয়ারিশগণের তালিকা","one":"ওয়ারিশ","req":[["name","নাম"],["rel","সম্পর্ক"]]},"admin":[]},"family":{"req":[["h_name","পরিবার প্রধানের নাম"],["h_father","পরিবার প্রধানের পিতার নাম"],["ward","ওয়ার্ড নং"],["village","গ্রাম"]],"list":{"t":"পরিবারের সদস্যদের তালিকা","one":"সদস্য","req":[["name","নাম"],["rel","সম্পর্ক"]]},"admin":[]},"same":{"req":[["alt_bn","অন্য নাম / ডাক নাম (বাংলা)"]],"list":null,"admin":[]},"trade":{"req":[["b_name","ব্যবসা প্রতিষ্ঠানের নাম"],["own","মালিকানার ধরন"],["b_type","ব্যবসার ধরন / প্রকৃতি (যেমন: মুদি দোকান)"],["b_addr","প্রতিষ্ঠানের ঠিকানা"],["ward","প্রতিষ্ঠানের ওয়ার্ড নং"],["kind","আবেদনের ধরন"]],"list":null,"admin":["fy","valid","lic","signb","sur","vat","tax","form","due","other"]}}', true);
    return $S;
}
function sp_check(string $kind, array $x): string {
    $S = spf()[$kind] ?? null;
    if (!$S) return '';
    foreach ($S['req'] as $f) if (s($x[$f[0]] ?? '') === '') return $f[1] . ' পূরণ করুন।';
    if ($S['list']) {
        $L = $x['list'] ?? null;
        if (!is_array($L) || !count($L)) return $S['list']['t'] . 'য় অন্তত একজন যোগ করুন।';
        foreach (array_values($L) as $i => $row) {
            foreach ($S['list']['req'] as $c) {
                if (s(is_array($row) ? ($row[$c[0]] ?? '') : '') === '') return $S['list']['one'] . ' ' . bn_digits((string)($i + 1)) . ': ' . $c[1] . ' পূরণ করুন।';
            }
        }
    }
    return '';
}

/* ---------------- আবেদন ---------------- */
function app_public(array $a): array {
    $o = [
        'id' => $a['id'], 'type' => $a['type'], 'name' => $a['name'], 'fa' => $a['fa'], 'mo' => $a['mo'], 'vl' => $a['vl'],
        'nid' => $a['nid'], 'mobile' => $a['mobile'], 'status' => $a['status'], 'date' => $a['date'],
        'note' => (string)($a['note'] ?? ''), 'cid' => $a['cid'] !== null ? (int)$a['cid'] : null,
        'fee' => $a['fee'], 'extra' => (string)($a['extra'] ?? ''),
    ];
    if ($a['memo'] !== '') $o['memo'] = $a['memo'];
    if ($a['issued_at'] !== '') $o['issuedAt'] = $a['issued_at'];
    if ($a['decided'] !== '') $o['decided'] = $a['decided'];
    $att = json_decode((string)($a['att'] ?? ''), true);
    if (is_array($att) && $att) $o['att'] = $att;
    return $o;
}
function app_row(string $id): ?array {
    $st = db()->prepare("SELECT * FROM apps WHERE id=?");
    $st->execute([$id]);
    $r = $st->fetch();
    return $r ?: null;
}
function new_app_id(): string {
    $ch = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    do {
        $id = 'UTH-';
        for ($i = 0; $i < 8; $i++) $id .= $ch[random_int(0, 35)];
    } while (app_row($id));
    return $id;
}

/* ================================================================
 * রাউটার
 * ================================================================ */
try {
    $path = (string)parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
    $p = strpos($path, '/api/');
    $route = $p === false ? '' : substr($path, $p + 4);          // যেমন: /citizen/login
    $route = '/' . trim(rawurldecode($route), '/');
    $M = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    $b = body();

    /* ---------- অ্যাডমিন লগইন ---------- */
    if ($route === '/login' && $M === 'POST') {
        throttle_check();
        $st = db()->prepare("SELECT * FROM admins WHERE email=?");
        $st->execute([strtolower(s($b['email'] ?? ''))]);
        $a = $st->fetch();
        if (!$a || !password_verify((string)($b['password'] ?? ''), $a['pass_hash'])) {
            throttle_fail();
            fail('ইমেইল বা পাসওয়ার্ড ভুল।', 401);
        }
        out(['token' => new_token('admin', (int)$a['id'])]);
    }

    if ($route === '/logout' && $M === 'POST') {
        $t = bearer();
        if ($t) db()->prepare("DELETE FROM sessions WHERE token_hash=?")->execute([hash('sha256', $t)]);
        out(['ok' => 1]);
    }

    /* ---------- নাগরিক লগইন ---------- */
    if ($route === '/citizen/login' && $M === 'POST') {
        throttle_check();
        $mob = norm_mobile(s($b['mobile'] ?? ''));
        $st = db()->prepare("SELECT id, pass_hash FROM citizens WHERE mobile=? AND pass_hash IS NOT NULL");
        $st->execute([$mob]);
        foreach ($st->fetchAll() as $c) {
            if (password_verify((string)($b['password'] ?? ''), $c['pass_hash'])) out(['token' => new_token('citizen', (int)$c['id'])]);
        }
        throttle_fail();
        fail('মোবাইল নম্বর বা পাসওয়ার্ড ভুল।', 401);
    }

    /* ---------- নাগরিক অ্যাকাউন্ট খোলা (পরিষদে আগে থেকে নিবন্ধিত তথ্যের সাথে মিলিয়ে) ---------- */
    if ($route === '/citizen/register' && $M === 'POST') {
        throttle_check();
        $pw = (string)($b['password'] ?? '');
        if (mb_strlen($pw) < 8) fail('পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে।');
        $mob = norm_mobile(s($b['mobile'] ?? ''));
        if (!preg_match('/^01[3-9]\d{8}$/', $mob)) fail('সঠিক মোবাইল নম্বর দিন (০১ দিয়ে শুরু, ১১ অঙ্ক)।');
        $doc = norm_doc(s($b['doc_no'] ?? ''));
        $dob = en_digits(s($b['dob'] ?? ''));
        if ($doc === '' || $dob === '') fail('ডকুমেন্ট নম্বর ও জন্ম তারিখ দিন।');
        $col = ['nid' => 'nid', 'ubrn' => 'birth_reg', 'passport' => 'passport'][s($b['doc_type'] ?? 'nid')] ?? 'nid';
        $st = db()->prepare("SELECT * FROM citizens WHERE $col=? AND dob=? LIMIT 1");
        $st->execute([$doc, $dob]);
        $c = $st->fetch();
        if (!$c) {
            throttle_fail();
            fail('এই ডকুমেন্ট নম্বর ও জন্ম তারিখে কোনো নিবন্ধিত নাগরিক পাওয়া যায়নি। আগে ইউনিয়ন পরিষদ কার্যালয়ে তথ্য নিবন্ধন করুন।', 404);
        }
        if ($c['pass_hash']) fail('এই তথ্যে আগেই অ্যাকাউন্ট খোলা হয়েছে। লগইন করুন, অথবা পাসওয়ার্ড ভুলে গেলে পরিষদে যোগাযোগ করুন।', 409);
        if (mobile_taken($mob, (int)$c['id'])) fail('এই মোবাইল নম্বরে আগেই আরেকটি অ্যাকাউন্ট আছে।', 409);
        $d = json_decode($c['data'], true) ?: [];
        $d['mobile'] = $mob;
        save_citizen_cols((int)$c['id'], $d);
        db()->prepare("UPDATE citizens SET pass_hash=? WHERE id=?")->execute([password_hash($pw, PASSWORD_DEFAULT), $c['id']]);
        out(['token' => new_token('citizen', (int)$c['id'])]);
    }

    /* ---------- নাগরিকের নিজের তথ্য ---------- */
    if ($route === '/citizen/me' && $M === 'GET') {
        $cid = need_citizen();
        $r = citizen_row($cid);
        if (!$r) fail('অনুগ্রহ করে আবার লগইন করুন।', 401);
        $c = citizen_public($r);
        unset($c['has_account']);
        $nid = (string)($c['nid'] ?? '');
        $c['nid'] = $nid !== '' ? str_repeat('*', max(0, strlen($nid) - 4)) . substr($nid, -4) : '';
        $st = db()->prepare("SELECT id, type, status, date FROM apps WHERE cid=? ORDER BY seq DESC");
        $st->execute([$cid]);
        out(['citizen' => $c, 'apps' => $st->fetchAll()]);
    }

    if ($route === '/citizen/profile' && $M === 'POST') {
        $cid = need_citizen();
        $r = citizen_row($cid);
        $d = json_decode($r['data'], true) ?: [];
        if (array_key_exists('mobile', $b)) {
            $mob = norm_mobile(s($b['mobile']));
            if (!preg_match('/^01[3-9]\d{8}$/', $mob)) fail('সঠিক মোবাইল নম্বর দিন (০১ দিয়ে শুরু, ১১ অঙ্ক)।');
            if (mobile_taken($mob, $cid)) fail('এই মোবাইল নম্বরে আগেই আরেকটি অ্যাকাউন্ট আছে।', 409);
            $d['mobile'] = $mob;
        }
        if (array_key_exists('photo', $b)) {
            $ph = s($b['photo']);
            if (!valid_image($ph, 3_000_000)) fail('ছবিটি গ্রহণযোগ্য নয় বা খুব বড়।');
            $d['photo'] = $ph;
        }
        save_citizen_cols($cid, $d);
        out(['ok' => 1]);
    }

    /* ---------- নাগরিকের আবেদন ---------- */
    if ($route === '/citizen/apply' && $M === 'POST') {
        $cid = need_citizen();
        $cfg = get_cfg();
        $type = s($b['type'] ?? '');
        $services = array_filter(array_map('trim', explode("\n", (string)($cfg['services'] ?? ''))));
        if ($type === '' || !in_array($type, $services, true)) fail('সনদের ধরন সঠিক নয়।');
        $fees = json_decode((string)($cfg['cert_fees'] ?? '{}'), true);
        $fz = is_array($fees) && isset($fees[$type]) && is_array($fees[$type]) ? $fees[$type] : [];
        if (($fz['on'] ?? true) === false) fail('এই সনদের আবেদন এখন বন্ধ আছে।', 403);
        $fee = (float)en_digits((string)($fz['fee'] ?? 0)) + (float)en_digits((string)($fz['charge'] ?? 0));
        $ex = '';
        $kind = SPT[$type] ?? '';
        if ($kind) {
            $x = is_array($b['extra'] ?? null) ? $b['extra'] : [];
            foreach (spf()[$kind]['admin'] as $k) unset($x[$k]);
            foreach (['show', 'tpl', 'comment', 'per'] as $k) unset($x[$k]);
            $er = sp_check($kind, $x);
            if ($er) fail($er);
            $ex = json_encode($x, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if (strlen($ex) > 200_000) fail('অতিরিক্ত তথ্য খুব বড়।');
        }
        $st = db()->prepare("SELECT 1 FROM apps WHERE cid=? AND type=? AND status='pending' LIMIT 1");
        $st->execute([$cid, $type]);
        if ($st->fetch()) fail('এই সনদের একটি আবেদন আগেই জমা আছে।', 409);
        $c = json_decode(citizen_row($cid)['data'], true) ?: [];
        $id = new_app_id();
        $date = bn_date();
        db()->prepare("INSERT INTO apps (id, cid, type, status, name, fa, mo, vl, nid, mobile, date, fee, note, extra, created_at)
                       VALUES (?,?,?,'pending',?,?,?,?,?,?,?,?,?,?,?)")->execute([
            $id, $cid, $type,
            mb_substr(s($c['name_bn'] ?? ''), 0, 190), mb_substr(s($c['father_bn'] ?? ''), 0, 190),
            mb_substr(s($c['mother_bn'] ?? ''), 0, 190), mb_substr(s($c['village_bn'] ?? ''), 0, 190),
            mb_substr(s($c['nid'] ?? ''), 0, 40), mb_substr(s($c['mobile'] ?? ''), 0, 20),
            $date, $fee ? (string)$fee : '', mb_substr(s($b['note'] ?? ''), 0, 2000), $ex, iso_now(),
        ]);
        out(['id' => $id, 'date' => $date]);
    }

    /* ---------- সাইট সেটিংস ---------- */
    if ($route === '/config') {
        if ($M === 'PUT' || $M === 'POST') {
            need_admin();
            $n = [];
            foreach ($b as $k => $v) {
                if (!is_string($k) || !preg_match('/^[a-z0-9_]{1,40}$/', $k)) continue;
                $n[$k] = is_scalar($v) || $v === null ? (string)$v : json_encode($v, JSON_UNESCAPED_UNICODE);
            }
            if (empty($n['services'])) $n['services'] = (string)(default_config()['services'] ?? '');
            save_cfg($n);
            out(['ok' => 1]);
        }
        $c = get_cfg();
        unset($c['cert_logo'], $c['watermark']);
        out((object)$c);
    }
    if ($route === '/admin/config' && $M === 'GET') { need_admin(); out((object)get_cfg()); }

    /* ---------- অ্যাডমিন: আবেদন ---------- */
    if ($route === '/admin/apps' && $M === 'GET') {
        need_admin();
        $L = db()->query("SELECT * FROM apps ORDER BY seq DESC")->fetchAll();
        out(array_map('app_public', $L));
    }

    if ($route === '/admin/status' && $M === 'POST') {
        need_admin();
        $status = s($b['status'] ?? '');
        if (!in_array($status, ['pending', 'approved', 'rejected'], true)) fail('অবস্থা সঠিক নয়।');
        $pdo = db();
        $pdo->beginTransaction();
        $st = $pdo->prepare("SELECT * FROM apps WHERE id=? FOR UPDATE");
        $st->execute([s($b['id'] ?? '')]);
        $a = $st->fetch();
        if (!$a) { $pdo->rollBack(); fail('আবেদন পাওয়া যায়নি।', 404); }
        $decided = $status !== 'pending' ? bn_date() : $a['decided'];
        $memo = $a['memo'];
        $issued = $a['issued_at'];
        if ($status === 'approved' && $memo === '') {
            $n = (int)$pdo->query("SELECT COUNT(*) n FROM apps WHERE memo<>''")->fetch()['n'];
            $memo = (string)(get_cfg()['memo_prefix'] ?? '') . str_pad((string)($n + 1), 4, '0', STR_PAD_LEFT);
            $issued = iso_now();
        }
        $pdo->prepare("UPDATE apps SET status=?, decided=?, memo=?, issued_at=? WHERE id=?")
            ->execute([$status, $decided, $memo, $issued, $a['id']]);
        $pdo->commit();
        out(['ok' => 1]);
    }

    if ($route === '/admin/app-extra' && $M === 'POST') {
        need_admin();
        $a = app_row(s($b['id'] ?? ''));
        if (!$a) fail('আবেদন পাওয়া যায়নি।', 404);
        $kind = SPT[$a['type']] ?? '';
        if (!$kind) fail('এই সনদে অতিরিক্ত তথ্য নেই।');
        $x = is_array($b['extra'] ?? null) ? $b['extra'] : [];
        $er = sp_check($kind, $x);
        if ($er) fail($er);
        db()->prepare("UPDATE apps SET extra=? WHERE id=?")->execute([json_encode($x, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $a['id']]);
        out(['ok' => 1]);
    }

    if ($route === '/admin/app-att' && $M === 'POST') {
        need_admin();
        $a = app_row(s($b['id'] ?? ''));
        if (!$a) fail('আবেদন পাওয়া যায়নি।', 404);
        $L = [];
        foreach (array_slice(is_array($b['att'] ?? null) ? $b['att'] : [], 0, 10) as $f) {
            if (!is_array($f)) continue;
            $d = (string)($f['d'] ?? '');
            if (!preg_match('#^data:(image/(jpeg|png|webp)|application/pdf);base64,#', $d) || strlen($d) > 8_000_000) continue;
            $L[] = ['n' => mb_substr(s($f['n'] ?? 'ফাইল') ?: 'ফাইল', 0, 120), 't' => s($f['t'] ?? ''), 'd' => $d];
        }
        db()->prepare("UPDATE apps SET att=? WHERE id=?")->execute([json_encode($L, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $a['id']]);
        out(['ok' => 1, 'att' => $L]);
    }

    /* ---------- অ্যাডমিন: নাগরিক ---------- */
    if (preg_match('#^/admin/citizen/(\d+)$#', $route, $m) && $M === 'GET') {
        need_admin();
        $r = citizen_row((int)$m[1]);
        if (!$r) fail('পাওয়া যায়নি', 404);
        out(citizen_public($r));
    }

    if ($route === '/admin/citizens' && $M === 'GET') {
        need_admin();
        $q = s($_GET['q'] ?? '');
        if ($q !== '') {
            $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';
            $qe = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], norm_doc($q)) . '%';
            $st = db()->prepare("SELECT * FROM citizens WHERE data LIKE ? OR nid LIKE ? OR birth_reg LIKE ? OR mobile LIKE ? ORDER BY id DESC");
            $st->execute([$like, $qe, $qe, $qe]);
        } else {
            $st = db()->query("SELECT * FROM citizens ORDER BY id DESC");
        }
        out(array_map('citizen_public', $st->fetchAll()));
    }

    if ($route === '/admin/citizens' && $M === 'POST') {
        need_admin();
        if (s($b['name_bn'] ?? '') === '') fail('নাম পূরণ করুন।');
        foreach (['father_bn', 'mother_bn', 'dob', 'gender', 'residency', 'ward', 'village_bn', 'marital', 'occupation', 'religion'] as $k) {
            if (s($b[$k] ?? '') === '') fail('সব তারকা চিহ্নিত ঘর পূরণ করুন।');
        }
        if (isset($b['photo']) && !valid_image(s($b['photo']), 3_000_000)) fail('ছবিটি গ্রহণযোগ্য নয় বা খুব বড়।');
        $id = (int)($b['id'] ?? 0);
        $old = $id ? citizen_row($id) : null;
        if ($id && !$old) fail('নাগরিক পাওয়া যায়নি।', 404);
        $d = $old ? (json_decode($old['data'], true) ?: []) : [];
        foreach (CIT_KEYS as $k) if (array_key_exists($k, $b)) $d[$k] = s($b[$k]);
        foreach (['nid', 'birth_reg', 'passport'] as $k) if (isset($d[$k])) $d[$k] = norm_doc($d[$k]);
        if (isset($d['mobile'])) $d['mobile'] = norm_mobile($d['mobile']);
        if (isset($d['dob'])) $d['dob'] = en_digits($d['dob']);
        // একই NID/জন্ম নিবন্ধন দিয়ে দুইবার নিবন্ধন আটকানো
        foreach (['nid' => 'এনআইডি', 'birth_reg' => 'জন্ম নিবন্ধন', 'passport' => 'পাসপোর্ট'] as $k => $lbl) {
            if (($d[$k] ?? '') === '') continue;
            $st = db()->prepare("SELECT id FROM citizens WHERE $k=? AND id<>? LIMIT 1");
            $st->execute([$d[$k], $id]);
            if ($st->fetch()) fail("এই $lbl নম্বরে আরেকজন নাগরিক আগেই নিবন্ধিত আছে।", 409);
        }
        if ($old && $old['pass_hash'] && ($d['mobile'] ?? '') !== '' && mobile_taken($d['mobile'], $id)) fail('এই মোবাইল নম্বরে আগেই আরেকটি অ্যাকাউন্ট আছে।', 409);
        if (!$id) {
            db()->prepare("INSERT INTO citizens (data, created_at) VALUES ('{}', ?)")->execute([iso_now()]);
            $id = (int)db()->lastInsertId();
        }
        save_citizen_cols($id, $d);
        out(['ok' => 1, 'id' => $id]);
    }

    /* ---------- সনদ যাচাই (সবার জন্য খোলা) ---------- */
    if (preg_match('#^/verify/(.+)$#', $route, $m) && $M === 'GET') {
        $a = app_row(strtoupper(trim($m[1])));
        if (!$a || $a['status'] !== 'approved') fail('এই নম্বরে কোনো বৈধ সনদ পাওয়া যায়নি।', 404);
        out(['type' => $a['type'], 'name' => $a['name'], 'date' => $a['decided'] ?: $a['date']]);
    }

    /* ---------- সনদ দেখা/প্রিন্ট (অ্যাডমিন অথবা সেই নাগরিক নিজে) ---------- */
    if (preg_match('#^/cert/(.+)$#', $route, $m) && $M === 'GET') {
        $a = app_row(strtoupper(trim($m[1])));
        $isAdmin = session_of('admin') !== null;
        $cid = $isAdmin ? null : session_of('citizen');
        if (!$isAdmin && $cid === null) fail('অনুগ্রহ করে আবার লগইন করুন।', 401);
        if (!$a || (!$isAdmin && ((int)$a['cid'] !== $cid || $a['status'] !== 'approved'))) fail('সনদ পাওয়া যায়নি।', 404);
        $cz = null;
        if ($a['cid'] !== null && ($r = citizen_row((int)$a['cid']))) $cz = citizen_public($r);
        if (!$cz) $cz = ['name_bn' => $a['name'], 'father_bn' => $a['fa'], 'mother_bn' => $a['mo'], 'village_bn' => $a['vl'], 'nid' => $a['nid'], 'mobile' => $a['mobile']];
        unset($cz['has_account']);
        out([
            'cfg' => (object)get_cfg(),
            'citizen' => $cz,
            'app' => ['id' => $a['id'], 'type' => $a['type'], 'extra' => (string)($a['extra'] ?? ''), 'memo' => $a['memo'], 'issued' => $a['issued_at'] ?: iso_now()],
        ]);
    }

    fail('পাওয়া যায়নি', 404);
} catch (PDOException $e) {
    error_log('UTH API DB error: ' . $e->getMessage());
    fail('সার্ভারে ডাটাবেস সমস্যা হয়েছে। (api/config.php-এর ডাটাবেস তথ্য ঠিক আছে কিনা দেখুন)', 500);
} catch (Throwable $e) {
    error_log('UTH API error: ' . $e->getMessage());
    fail('সার্ভারে সমস্যা হয়েছে।', 500);
}
