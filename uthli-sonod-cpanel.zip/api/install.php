<?php
/*
 * এককালীন সেটআপ: ডাটাবেসের টেবিল তৈরি + প্রথম অ্যাডমিন অ্যাকাউন্ট।
 * ব্রাউজারে খুলুন: https://আপনার-ডোমেইন/api/install.php
 * কাজ শেষ হলে cPanel File Manager থেকে এই ফাইলটি মুছে দিন।
 */
declare(strict_types=1);
define('UTH_APP', 1);
require __DIR__ . '/lib.php';
header('Content-Type: text/html; charset=utf-8');
header('X-Robots-Tag: noindex');

$msg = ''; $ok = false; $installed = false; $dbErr = '';
try {
    create_tables();
    $installed = (int)db()->query("SELECT COUNT(*) n FROM admins")->fetch()['n'] > 0;
} catch (Throwable $e) {
    $dbErr = $e->getMessage();
}

if (!$dbErr && !$installed && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $p1 = (string)($_POST['p1'] ?? ''); $p2 = (string)($_POST['p2'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $msg = 'সঠিক ইমেইল দিন।';
    elseif (mb_strlen($p1) < 10) $msg = 'পাসওয়ার্ড কমপক্ষে ১০ অক্ষরের দিন।';
    elseif ($p1 !== $p2) $msg = 'দুই জায়গায় পাসওয়ার্ড মেলেনি।';
    else {
        db()->prepare("INSERT INTO admins (email, pass_hash, created_at) VALUES (?,?,?)")
            ->execute([$email, password_hash($p1, PASSWORD_DEFAULT), iso_now()]);
        $has = db()->query("SELECT COUNT(*) n FROM settings WHERE k='cfg'")->fetch()['n'];
        if (!(int)$has) {
            db()->prepare("INSERT INTO settings (k, v) VALUES ('cfg', ?)")
                ->execute([json_encode(default_config(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
        }
        $ok = true; $installed = true;
    }
}
$h = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
?><!DOCTYPE html>
<html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>সেটআপ – ডিজিটাল সনদ সেবা</title>
<style>body{font:16px/1.6 system-ui,sans-serif;background:#f1f5f3;margin:0;padding:24px;color:#14201c}
.c{max-width:460px;margin:30px auto;background:#fff;border-radius:12px;padding:24px;box-shadow:0 4px 20px rgba(0,0,0,.08)}
h1{font-size:22px;margin:0 0 12px;color:#006838}label{display:block;margin-top:12px;font-weight:600}
input{width:100%;box-sizing:border-box;padding:10px;font:inherit;border:1px solid #c9d6d0;border-radius:8px}
button{margin-top:18px;width:100%;padding:12px;font:inherit;font-weight:700;background:#006838;color:#fff;border:0;border-radius:8px;cursor:pointer}
.e{color:#b3261e}.ok{color:#006838}.box{background:#fff7e6;border:1px solid #f0c36d;padding:10px 12px;border-radius:8px;margin-top:14px}code{background:#eef3f1;padding:1px 5px;border-radius:4px}</style></head>
<body><div class="c">
<h1>ডিজিটাল সনদ সেবা – সেটআপ</h1>
<?php if ($dbErr): ?>
  <p class="e"><b>ডাটাবেসে সংযোগ হয়নি।</b></p>
  <p><code>api/config.php</code> ফাইলে ডাটাবেসের নাম, ইউজার ও পাসওয়ার্ড ঠিকমতো লিখেছেন কিনা দেখুন, এবং cPanel-এ ইউজারকে ডাটাবেসে <b>ALL PRIVILEGES</b> দিয়েছেন কিনা নিশ্চিত করুন।</p>
  <p style="font-size:13px;color:#666">বিস্তারিত: <?= $h($dbErr) ?></p>
<?php elseif ($ok): ?>
  <p class="ok"><b>সেটআপ সম্পন্ন হয়েছে!</b> অ্যাডমিন অ্যাকাউন্ট তৈরি হয়েছে।</p>
  <div class="box"><b>জরুরি:</b> এখনই cPanel → File Manager থেকে <code>api/install.php</code> ফাইলটি মুছে দিন।</div>
  <p><a href="/admin/">অ্যাডমিন প্যানেলে যান →</a></p>
<?php elseif ($installed): ?>
  <p>সেটআপ আগেই সম্পন্ন হয়েছে। নিরাপত্তার জন্য এই পাতা আর কিছু করবে না।</p>
  <div class="box">cPanel → File Manager থেকে <code>api/install.php</code> ফাইলটি মুছে দিন।</div>
<?php else: ?>
  <p>ডাটাবেস সংযোগ ঠিক আছে ✅। এখন প্রথম অ্যাডমিন অ্যাকাউন্ট তৈরি করুন।</p>
  <?php if ($msg): ?><p class="e"><?= $h($msg) ?></p><?php endif; ?>
  <form method="post" autocomplete="off">
    <label for="email">অ্যাডমিন ইমেইল</label><input id="email" name="email" type="email" required value="<?= $h($_POST['email'] ?? '') ?>">
    <label for="p1">পাসওয়ার্ড (কমপক্ষে ১০ অক্ষর)</label><input id="p1" name="p1" type="password" required>
    <label for="p2">পাসওয়ার্ড আবার লিখুন</label><input id="p2" name="p2" type="password" required>
    <button>সেটআপ সম্পন্ন করুন</button>
  </form>
<?php endif; ?>
</div></body></html>
