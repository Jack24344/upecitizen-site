<?php
/* সাধারণ ফাংশন: ডাটাবেস সংযোগ, টেবিল তৈরি, সহায়ক ফাংশন */
declare(strict_types=1);

if (!defined('UTH_APP')) { http_response_code(403); exit; }

date_default_timezone_set('Asia/Dhaka');

function cfg_file(): array {
    static $c = null;
    if ($c === null) $c = require __DIR__ . '/config.php';
    return $c;
}

function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $c = cfg_file();
    $dsn = $c['dsn'] ?? ('mysql:host=' . $c['db_host'] . ';dbname=' . $c['db_name'] . ';charset=utf8mb4');
    $pdo = new PDO($dsn, $c['db_user'] ?? null, $c['db_pass'] ?? null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $pdo->exec("SET time_zone = '+06:00'");
    return $pdo;
}

function create_tables(): void {
    $T = [
        "CREATE TABLE IF NOT EXISTS admins (
            id INT AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(190) NOT NULL UNIQUE,
            pass_hash VARCHAR(255) NOT NULL,
            created_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS sessions (
            token_hash CHAR(64) PRIMARY KEY,
            kind VARCHAR(10) NOT NULL,
            uid INT NOT NULL,
            expires_at INT NOT NULL,
            INDEX (expires_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS citizens (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name_bn VARCHAR(190) NOT NULL DEFAULT '',
            mobile VARCHAR(20) NOT NULL DEFAULT '',
            nid VARCHAR(40) NOT NULL DEFAULT '',
            birth_reg VARCHAR(40) NOT NULL DEFAULT '',
            passport VARCHAR(40) NOT NULL DEFAULT '',
            dob VARCHAR(20) NOT NULL DEFAULT '',
            pass_hash VARCHAR(255) NULL,
            data LONGTEXT NOT NULL,
            created_at DATETIME NOT NULL,
            INDEX (mobile), INDEX (nid), INDEX (birth_reg), INDEX (passport)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS apps (
            seq INT AUTO_INCREMENT PRIMARY KEY,
            id VARCHAR(20) NOT NULL UNIQUE,
            cid INT NULL,
            type VARCHAR(190) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            name VARCHAR(190) NOT NULL DEFAULT '',
            fa VARCHAR(190) NOT NULL DEFAULT '',
            mo VARCHAR(190) NOT NULL DEFAULT '',
            vl VARCHAR(190) NOT NULL DEFAULT '',
            nid VARCHAR(40) NOT NULL DEFAULT '',
            mobile VARCHAR(20) NOT NULL DEFAULT '',
            date VARCHAR(40) NOT NULL DEFAULT '',
            decided VARCHAR(40) NOT NULL DEFAULT '',
            memo VARCHAR(60) NOT NULL DEFAULT '',
            issued_at VARCHAR(40) NOT NULL DEFAULT '',
            fee VARCHAR(20) NOT NULL DEFAULT '',
            note TEXT NULL,
            extra LONGTEXT NULL,
            att LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            INDEX (cid), INDEX (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS settings (
            k VARCHAR(50) PRIMARY KEY,
            v LONGTEXT NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS login_fail (
            ip VARCHAR(64) NOT NULL,
            at INT NOT NULL,
            INDEX (ip, at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    ];
    foreach ($T as $sql) db()->exec($sql);
}

/* বাংলা অঙ্ক → ইংরেজি অঙ্ক */
function en_digits(string $s): string {
    return strtr($s, ['০'=>'0','১'=>'1','২'=>'2','৩'=>'3','৪'=>'4','৫'=>'5','৬'=>'6','৭'=>'7','৮'=>'8','৯'=>'9']);
}
function bn_digits(string $s): string {
    return strtr($s, ['0'=>'০','1'=>'১','2'=>'২','3'=>'৩','4'=>'৪','5'=>'৫','6'=>'৬','7'=>'৭','8'=>'৮','9'=>'৯']);
}
/* ব্রাউজারের toLocaleDateString("bn-BD") এর মতো: ৫/৩/২০২৬ */
function bn_date(): string { return bn_digits(date('j/n/Y')); }
/* toLocaleString("sv-SE",{timeZone:"Asia/Dhaka"}) এর মতো: 2026-11-16 18:08:00 */
function iso_now(): string { return date('Y-m-d H:i:s'); }

function default_config(): array {
    $j = json_decode((string)@file_get_contents(__DIR__ . '/default_config.json'), true);
    return is_array($j) ? $j : [];
}
